<html>
    <head>
    	<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
		<link href='style.css' rel='stylesheet' type='text/css'>
		<script src="https://d3js.org/d3.v3.min.js"></script>
		
    </head>
    <body>

    	<h1 id="dashTitle">2017 Sales Dashboard</h1>

    	<div id="topChart" style="float: left; width: 800px;">
			<h2 style="margin-left:50px; float:left;">Sales by Month (colored by profit)</h1>				
			<svg id="barChartLegend"></svg>
	    	<svg id="barChart"></svg>
	    </div>

	    <div id="bottomLeft" style="float:left; width: 350px; margin-left: 50px;"></div>

	    <div id="bottomRight" style="float:left; width: 400px;">
	    	<h2>Sales by State</h2>	    	    		
	    </div>


		<script src="js/global-functions.js"></script>
		<script src="js/bar-chart.js"></script>
		<script src="js/sparklines.js"></script>
		<script src="js/map.js"></script>

    </body>
</html>